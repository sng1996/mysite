CREATE PROCEDURE `otchet`(`cur_year` INT(11))
  BEGIN
  declare b_copy int;
  declare summa_copy int;
  declare address_value varchar(64);
  declare date_value DATE;
  declare district_value varchar(8);
  declare s_value int;
  declare pr int;
  declare cost int;
  CREATE VIEW v AS select sum(price) as summa, year, B_id as b from billboard join timetable using(B_id) group by B_id, year;
  select b, summa INTO b_copy, summa_copy from v where summa = (select max(summa) from v) and year=cur_year limit 1;
  select Date, S, Address, Price, Name into date_value, s_value, address_value, pr, district_value
    from billboard JOIN district USING(B_id)
  where B_id=b_copy;
  insert into report values(NULL, address_value, date_value, district_value, s_value, pr, summa_copy, cur_year);
  drop view v;
END